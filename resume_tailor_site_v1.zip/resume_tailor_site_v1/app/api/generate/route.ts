import { NextRequest, NextResponse } from "next/server";
import { callClaude } from "@/lib/anthropic";
import { COVER_SYSTEM_PROMPT, RESUME_SYSTEM_PROMPT } from "@/lib/prompts";

type GenerateRequest = {
  mode: "resume" | "cover-letter" | "both";
  jobDescription: string;
  resumeTemplate: string;
  coverLetterTemplate: string;
};

function stripCodeFences(text: string) {
  return text.replace(/^```[a-zA-Z]*\n?/, "").replace(/```$/, "").trim();
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as GenerateRequest;

    if (!body.jobDescription?.trim()) {
      return NextResponse.json(
        { error: "Job description is required." },
        { status: 400 }
      );
    }

    if (!body.resumeTemplate?.trim()) {
      return NextResponse.json(
        { error: "Resume template is required." },
        { status: 400 }
      );
    }

    if (!body.coverLetterTemplate?.trim()) {
      return NextResponse.json(
        { error: "Cover letter template is required." },
        { status: 400 }
      );
    }

    const result: {
      resumeLatex?: string;
      coverLetterLatex?: string;
    } = {};

    if (body.mode === "resume" || body.mode === "both") {
      const resumePrompt = `
Job description:
${body.jobDescription}

Original resume LaTeX:
${body.resumeTemplate}

Return a tailored version of the same LaTeX resume.
Important:
- Keep the same LaTeX macros and overall layout.
- Preserve factual content.
- Only tailor wording to better fit the job description.
- Keep it one page in spirit.
`;
      result.resumeLatex = stripCodeFences(
        await callClaude({
          system: RESUME_SYSTEM_PROMPT,
          userPrompt: resumePrompt
        })
      );
    }

    if (body.mode === "cover-letter" || body.mode === "both") {
      const coverPrompt = `
Job description:
${body.jobDescription}

Resume source of truth:
${body.resumeTemplate}

Preferred cover letter template:
${body.coverLetterTemplate}

Return a tailored LaTeX cover letter that follows the same general style and structure as the provided template.
Important:
- Use the resume as the factual source of truth.
- Update company, role, and body content to fit the job description.
- Keep the output concise, polished, and believable.
`;
      result.coverLetterLatex = stripCodeFences(
        await callClaude({
          system: COVER_SYSTEM_PROMPT,
          userPrompt: coverPrompt
        })
      );
    }

    return NextResponse.json(result);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Something went wrong.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
