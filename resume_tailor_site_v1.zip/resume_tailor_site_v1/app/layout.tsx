import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Resume Tailor",
  description: "Tailor a LaTeX resume and generate a LaTeX cover letter with Claude."
};

export default function RootLayout({
  children
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
