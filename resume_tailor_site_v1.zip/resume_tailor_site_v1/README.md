# Resume Tailor + Cover Letter Generator

A Next.js app you can push to GitHub and deploy on Railway.

It uses your Claude API key to:
- tailor a LaTeX resume to a pasted job description
- generate a LaTeX cover letter that roughly follows your preferred format
- let you download the generated `.tex` files

## 1. Local setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

## 2. Environment variables

Add these in Railway too:

```bash
ANTHROPIC_API_KEY=your_key_here
CLAUDE_MODEL=claude-sonnet-4-5
```

## 3. Deploy to Railway

1. Push this folder to GitHub
2. Create a new Railway project
3. Connect your GitHub repo
4. Add the environment variables
5. Deploy

## 4. Notes

This MVP is designed to work best when your resume is already in LaTeX, which matches your workflow.

It does **not** invent experience. The prompt explicitly tells Claude to:
- preserve structure
- keep dates and employers unchanged
- only tailor wording based on the job description
- avoid fake numbers, tools, and achievements

## 5. Future upgrades

- PDF/DOCX parsing
- compile LaTeX to PDF with Tectonic
- save past jobs
- ATS keyword gap panel
