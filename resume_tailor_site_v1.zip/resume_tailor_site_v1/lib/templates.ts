export const defaultResumeTemplate = String.raw`\documentclass[10pt,letterpaper]{article}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[top=0.65cm,bottom=0.65cm,left=0.9cm,right=0.9cm]{geometry}
\usepackage{titlesec}
\usepackage{xcolor}
\usepackage{enumitem}
\usepackage{hyperref}
\usepackage{array}
\definecolor{primaryColor}{RGB}{0,0,0}
\hypersetup{
  colorlinks=true,
  urlcolor=primaryColor,
  pdftitle={Danyal Shahzad – Resume},
  pdfauthor={Danyal Shahzad}
}
\raggedright
\pagestyle{empty}
\setcounter{secnumdepth}{0}
\setlength{\parindent}{0pt}
\renewcommand\labelitemi{$\vcenter{\hbox{\small$\bullet$}}$}
\titleformat{\section}{\bfseries\large}{}{0pt}{}[\titlerule]
\titlespacing*{\section}{0pt}{0.13cm}{0.07cm}
\newcommand{\baseRole}[4]{%
  \noindent\begin{tabular*}{\textwidth}{@{}p{0.74\textwidth}@{\extracolsep{\fill}}r@{}}%
  \textbf{#1} & \textbf{\textit{#2}}\\%
  \textit{#3} & \textit{#4}\\%
  \end{tabular*}\vspace{0.03cm}%
}
\newcommand{\role}[4]{\baseRole{#1}{#2}{#3}{#4}}
\newcommand{\nextrole}[4]{\vspace{0.04cm}\baseRole{#1}{#2}{#3}{#4}}
\newenvironment{highlights}
  {\begin{itemize}[topsep=0.03cm,itemsep=0.6pt,leftmargin=11pt,parsep=0pt]}
  {\end{itemize}}
\newcommand{\header}{
  \begin{center}
    {\fontsize{21pt}{21pt}\selectfont \textbf{Danyal Shahzad}}\\[2pt]
    (647)~287--2132 \,|\, 
    \href{mailto:mshahzadd10@gmail.com}{mshahzadd10@gmail.com} \,|\, 
    \href{https://danyalshahzad1.github.io/}{https://danyalshahzad1.github.io/}
  \end{center}
}
\begin{document}
\header
\section{Education}
\role{Master of Finance, McMaster University -- DeGroote School of Business}
     {Sep 2025 -- Present}
     {Hamilton, ON}
     {GPA: 3.7 / 4.0}

\nextrole{Honours Bachelor of Commerce (Finance Specialization), McMaster University}
     {Sep 2020 -- Jun 2025}
     {Hamilton, ON}
     {GPA: 3.5 / 4.0}

\section{Finance \& Professional Experience}
\role{Part-Time Sales Associate | Moores Clothing for Men}
     {Aug 2025 -- Present}
     {Mississauga, ON}
     {}
\begin{highlights}
\item Reconcile daily POS transactions (\$1.5K--\$3K per shift), performing cash balancing and deposit preparation in line with internal control procedures.
\item Assist with end-of-day close and transaction verification processes, ensuring revenue integrity and adherence to loss prevention protocols.
\end{highlights}

\nextrole{Financial Analyst Intern | Martinrea International (TSX: MRE)}
     {Jun 2023 -- Aug 2024}
     {Vaughan, ON}
     {}
\begin{highlights}
\item Built multi-scenario Excel forecasting models for a \$20M automotive business unit, integrating revenue, COGS, and SG\&A assumptions to support annual budget planning and quarterly reforecasting for senior leadership.
\item Conducted monthly variance analysis across 15+ cost centers, isolating volume, price, and mix variances that informed pricing adjustments and contributed to a 200 bps margin improvement initiative.
\item Designed executive-level Power BI dashboards tracking gross margin, working capital turnover, and operational KPIs, replacing manual Excel reports and reducing monthly reporting cycle time by 15\%.
\item Extracted and analyzed large ERP and CRM datasets to identify trends in customer profitability, supporting data-driven resource allocation decisions across cross-functional teams.
\end{highlights}

\nextrole{Administrative Analyst | Investrade Company}
     {Jun 2022 -- Sep 2022}
     {Manama, Bahrain}
     {}
\begin{highlights}
\item Reconciled and validated financial data across CRM, Excel, and SAP platforms; assisted in portfolio monitoring and weekly P\&L performance tracking for a multi-asset investment portfolio.
\item Documented and optimized 10+ internal workflows across CRM and SAP systems, improving reporting efficiency by 20\% through automation and enhanced data validation processes.
\item Supported finance and risk teams with data entry, report preparation, and ad-hoc analysis requests during quarterly review cycles.
\end{highlights}

\section{Projects \& Leadership}
\role{Equity Valuation -- Lundin Mining Corporation (TSX: LUN)}
     {Sep 2025 -- Oct 2025}
     {Hamilton, ON}
     {}
\begin{highlights}
\item Built a full equity valuation using DCF (WACC-based), DDM, and EV/EBITDA comps; modeled five-year integrated financial statements with commodity price assumptions and sensitivity analyses using Refinitiv and Bloomberg data.
\item Presented investment thesis and risk analysis to faculty and industry professionals, defending discount rate, terminal growth, and commodity assumptions under live Q\&A.
\end{highlights}

\nextrole{Strategic Consulting Project -- Hamilton Public Library}
     {Jan 2025 -- Mar 2025}
     {Hamilton, ON}
     {}
\begin{highlights}
\item Led a data-driven patron engagement analysis identifying retention gaps; developed a strategic recommendation deck with actionable initiatives and presented findings to library leadership across a full consulting engagement cycle.
\end{highlights}

\nextrole{DeGroote Finance and Investment Council (DFIC)}
     {Sep 2021 -- Apr 2023}
     {Hamilton, ON}
     {}
\begin{highlights}
\item Organized stock pitch sessions, valuation workshops, and case competitions; represented McMaster at national finance competitions, developing applied skills in equity research and financial modeling.
\end{highlights}

\section{Athletics}
\role{Semi-Professional Footballer | North Mississauga SC}
     {2023 -- Present}
     {Mississauga, ON}
     {Ontario Premier League}
\begin{highlights}
\item Compete at a semi-professional level while maintaining a 3.5+ GPA and professional commitments; demonstrates discipline, time management, and composure under pressure.
\end{highlights}

\section{Technical Skills}
\textbf{Financial \& Analytical Tools:} Excel (advanced financial modeling, VBA), Power BI, Python (pandas, NumPy), SAP, VENA, Bloomberg Terminal, Refinitiv Eikon, Github.\\[2pt]
\textbf{Core Competencies:} Financial Modeling \& Valuation (DCF, Comps, LBO), Budgeting \& Forecasting, Variance Analysis, KPI Reporting, Data Visualization.
\end{document}
`;

export const defaultCoverLetterTemplate = String.raw`\documentclass[11pt,letterpaper]{article}

\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{newtxtext}
\usepackage[margin=1in]{geometry}
\usepackage{setspace}
\usepackage{parskip}
\usepackage[hidelinks]{hyperref}
\usepackage{fancyhdr}

\pagestyle{fancy}
\fancyhf{}
\renewcommand{\headrulewidth}{0pt}
\pagenumbering{gobble}

\setstretch{1.1}
\setlength{\parindent}{0pt}

\begin{document}

\begin{center}
{\Huge \textbf{Danyal Shahzad}}\\
Mississauga, ON $\cdot$ 647--287--2132 $\cdot$
\href{mailto:mshahzadd10@gmail.com}{mshahzadd10@gmail.com}
\end{center}

\vspace{8pt}
\hrule
\vspace{16pt}

April 1, 2026 \\
Hiring Committee \\
Williams \& Partners Chartered Professional Accountants LLP \\
Markham, ON

\vspace{6pt}

Dear Hiring Committee,

I am writing to express my interest in the Valuation Analyst position at Williams \& Partners. As a Master of Finance student at McMaster University with a strong foundation in financial analysis and valuation, I am excited about the opportunity to contribute to valuation and corporate advisory engagements while developing my technical skill set in a hands-on environment.

I am particularly drawn to this role because of its exposure to valuation, M\&A, and financial advisory work. The opportunity to build valuation models, perform detailed financial statement analysis, and support the preparation of client deliverables such as reports and information memorandums aligns closely with my interest in applying financial theory to real-world transactions. I am especially interested in further developing my understanding of valuation methodologies and industry analysis.

Through my academic and professional experience, I have developed strong technical skills in Excel, financial modeling, and data analysis. During my time as a Finance Analyst Intern at Martinrea International, I worked with financial statements, supported reporting processes, and analyzed data to identify key trends and discrepancies. In addition, I have built valuation models and conducted company analysis through academic projects, strengthening my ability to interpret financial performance and assess value.

In addition, my experience has helped me build strong attention to detail and the ability to work under tight deadlines. I am comfortable managing multiple priorities, conducting research, and presenting findings clearly. I bring a strong work ethic, a willingness to learn, and a proactive approach to problem-solving, which I believe are important in a fast-paced advisory environment.

What excites me most about Williams \& Partners is the opportunity to work closely with experienced professionals in a collaborative setting while gaining exposure to a wide range of industries and transactions. I am eager to contribute to valuation engagements, support client deliverables, and continue developing my analytical and professional skills.

Thank you for your time and consideration. I would welcome the opportunity to further discuss how my background and interest in valuation and advisory can contribute to your team.

\vspace{2pt}

Sincerely,\\
Danyal Shahzad

\end{document}
`;
