import Anthropic from "@anthropic-ai/sdk";

function getClient() {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error("Missing ANTHROPIC_API_KEY environment variable.");
  }
  return new Anthropic({ apiKey });
}

export async function callClaude(input: {
  system: string;
  userPrompt: string;
}) {
  const client = getClient();
  const model = process.env.CLAUDE_MODEL || "claude-sonnet-4-5";

  const response = await client.messages.create({
    model,
    max_tokens: 4000,
    temperature: 0.2,
    system: input.system,
    messages: [
      {
        role: "user",
        content: input.userPrompt
      }
    ]
  });

  const text = response.content
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n")
    .trim();

  if (!text) {
    throw new Error("Claude returned an empty response.");
  }

  return text;
}
