"use client";

import { useMemo, useState } from "react";
import { defaultCoverLetterTemplate, defaultResumeTemplate } from "@/lib/templates";
import { downloadTextFile } from "@/lib/download";

type Mode = "resume" | "cover-letter" | "both";

type ApiResponse = {
  resumeLatex?: string;
  coverLetterLatex?: string;
  error?: string;
};

export default function AppClient() {
  const [mode, setMode] = useState<Mode>("both");
  const [jobDescription, setJobDescription] = useState("");
  const [resumeTemplate, setResumeTemplate] = useState(defaultResumeTemplate);
  const [coverLetterTemplate, setCoverLetterTemplate] = useState(defaultCoverLetterTemplate);
  const [resumeOutput, setResumeOutput] = useState("");
  const [coverOutput, setCoverOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const canGenerate = useMemo(() => {
    return Boolean(jobDescription.trim() && resumeTemplate.trim() && coverLetterTemplate.trim());
  }, [jobDescription, resumeTemplate, coverLetterTemplate]);

  async function handleGenerate() {
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          mode,
          jobDescription,
          resumeTemplate,
          coverLetterTemplate
        })
      });

      const data = (await res.json()) as ApiResponse;

      if (!res.ok) {
        throw new Error(data.error || "Request failed.");
      }

      setResumeOutput(data.resumeLatex || "");
      setCoverOutput(data.coverLetterLatex || "");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  function handleTemplateUpload(
    event: React.ChangeEvent<HTMLInputElement>,
    type: "resume" | "cover"
  ) {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === "string" ? reader.result : "";
      if (type === "resume") {
        setResumeTemplate(text);
      } else {
        setCoverLetterTemplate(text);
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="page">
      <div className="hero">
        <span className="badge">GitHub + Railway + Claude API</span>
        <h1>Resume Tailor</h1>
        <p>
          Paste a job description, keep your LaTeX resume structure, and generate a tailored
          resume plus cover letter using your Claude API key on the server.
        </p>
      </div>

      <div className="grid">
        <div className="stack">
          <div className="card stack">
            <div>
              <label className="label">Mode</label>
              <div className="row">
                <button className={`button ${mode === "resume" ? "" : "secondary"}`} onClick={() => setMode("resume")}>
                  Tailor Resume
                </button>
                <button className={`button ${mode === "cover-letter" ? "" : "secondary"}`} onClick={() => setMode("cover-letter")}>
                  Generate Cover Letter
                </button>
                <button className={`button ${mode === "both" ? "" : "secondary"}`} onClick={() => setMode("both")}>
                  Do Both
                </button>
              </div>
            </div>

            <div>
              <label className="label" htmlFor="jobDescription">Job description</label>
              <textarea
                id="jobDescription"
                className="textarea large"
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                placeholder="Paste the full job description here..."
              />
            </div>

            <div className="row">
              <button className="button" onClick={handleGenerate} disabled={!canGenerate || loading}>
                {loading ? "Generating..." : "Generate"}
              </button>
              <button
                className="button secondary"
                onClick={() => {
                  setJobDescription("");
                  setResumeOutput("");
                  setCoverOutput("");
                  setError("");
                }}
                disabled={loading}
              >
                Clear Job Description
              </button>
            </div>

            {error ? <div className="small">Error: {error}</div> : null}
          </div>

          <div className="card stack">
            <div>
              <label className="label">Resume template (.tex or .txt)</label>
              <input type="file" accept=".tex,.txt,.md" onChange={(e) => handleTemplateUpload(e, "resume")} />
              <p className="small">You can paste directly below or upload your LaTeX resume file.</p>
            </div>
            <textarea
              className="textarea large"
              value={resumeTemplate}
              onChange={(e) => setResumeTemplate(e.target.value)}
            />
          </div>

          <div className="card stack">
            <div>
              <label className="label">Cover letter template (.tex or .txt)</label>
              <input type="file" accept=".tex,.txt,.md" onChange={(e) => handleTemplateUpload(e, "cover")} />
              <p className="small">This is the style Claude will roughly follow when generating the cover letter.</p>
            </div>
            <textarea
              className="textarea large"
              value={coverLetterTemplate}
              onChange={(e) => setCoverLetterTemplate(e.target.value)}
            />
          </div>
        </div>

        <div className="stack">
          <div className="card stack">
            <div>
              <h2 className="outputTitle">Tailored Resume Output</h2>
              <p className="meta">Raw LaTeX you can save as <code>resume.tex</code>.</p>
            </div>
            <div className="pre">{resumeOutput || "Your tailored resume will appear here."}</div>
            <div className="row">
              <button
                className="button secondary"
                disabled={!resumeOutput}
                onClick={() => downloadTextFile("tailored_resume.tex", resumeOutput)}
              >
                Download Resume .tex
              </button>
            </div>
          </div>

          <div className="card stack">
            <div>
              <h2 className="outputTitle">Cover Letter Output</h2>
              <p className="meta">Raw LaTeX you can save as <code>cover_letter.tex</code>.</p>
            </div>
            <div className="pre">{coverOutput || "Your tailored cover letter will appear here."}</div>
            <div className="row">
              <button
                className="button secondary"
                disabled={!coverOutput}
                onClick={() => downloadTextFile("tailored_cover_letter.tex", coverOutput)}
              >
                Download Cover Letter .tex
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
